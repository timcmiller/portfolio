TIM C MILLER PORTFOLIO

==============================

Simple portfolio for showcasing my work.

You can find the prototype at timcmiller.herokuapp.com
